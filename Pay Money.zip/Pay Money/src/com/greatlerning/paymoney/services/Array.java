package com.greatlerning.paymoney.services;

import java.util.Scanner;

public class Array {
	public static Scanner sc = new Scanner(System.in);
	public static int i;

	public int[] createArray(int[] arr) {      //create an array and receiving the data from console
		
		for (i = 0; i < arr.length ; i++) {
			System.out.println("Enter the values of array");
			arr[i] = sc.nextInt();
		}

		return arr;

	}

	public void traverseArray(int[] arr) {    //traversing the data from array to console
		System.out.print("The Array: ");
		for (i = 0; i < arr.length; i++) {
			System.out.print(arr[i]);
		}
		System.out.println();
	}
	
	

}
