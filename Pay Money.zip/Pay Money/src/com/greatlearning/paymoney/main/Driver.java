package com.greatlearning.paymoney.main;

import java.util.Scanner;

import com.greatlearning.paymoney.beans.TargetCal;
import com.greatlerning.paymoney.services.Array;

public class Driver {

	public static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("Enter the size of transaction array");
		int sizeArr = sc.nextInt();
		int[] arr = new int[sizeArr]; // initiate an array space in memory
		Array array = new Array(); // instance of array class
		array.createArray(arr); // calling createArray function
		// array.traverseArray(arr); // calling traverse function
		System.out.println("Enter the total no of targets that needs to be achieved");
		int targetNum = sc.nextInt();
		if (targetNum > 0) {
			TargetCal tc = new TargetCal(); // instance of targetCal class
			tc.achievableTarget(targetNum, arr);
		}else System.out.println("Please provide the value greater than 0");
	}

}
