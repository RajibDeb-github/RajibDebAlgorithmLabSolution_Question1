package com.greatlearning.paymoney.beans;

import java.util.Scanner;

public class TargetCal {
	public void achievableTarget(int targetNum, int[] arr) {
		Scanner sc = new Scanner(System.in);
		for (int tar = 0; tar < targetNum; tar++) { // 1
			System.out.println("Enter the value of target");
			int targetVal = sc.nextInt();
			int totalSum = 0;
			for (int i = 0; i < arr.length; i++) {
				totalSum = totalSum + arr[i];
			}
			int rem = targetVal;
			if (targetVal > 0) { // 1       Ensuring the target value must be greater than 0
				if (totalSum > targetVal) {// 3      
					for (int i = 0; i < arr.length; i++) { // 2

						if (rem <= arr[i]) { // 2
							System.out.println("The target is achieved after " + (i + 1) + " Transaction");
							break;
						} // if2
						rem = rem - arr[i];
						// System.out.println(rem);

					} // for2
				} // if3
				else {
					System.out.println("Given target is not achieved");
				} // else3
			} // if1
			else {
				System.out.println("The target value must be greater than 0");
			} // else1

		} // for1

	} // achievableTarget

}
